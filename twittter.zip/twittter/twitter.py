from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Initialize the Chrome WebDriver
driver = webdriver.Chrome()

# Twitter URL for login
url = "https://x.com/i/flow/login"

driver.get(url)

# Prompt user for login method
print("LOGIN METHOD:")
print("1. Twitter Authentication")
print("2. Google")
print("3. Apple")

login_method = input("Choose login method (1, 2, or 3): ")

# Define the login functions
def signin_twitter_auth(username, password):
    # Navigate to Twitter login page
    time.sleep(3)  # Wait for the page to load
    # Locate the username field and enter the username
    username_field = driver.find_element(By.XPATH, "//input[@name = 'text']")
    username_field.send_keys(username)
    username_field.send_keys(Keys.RETURN)
    time.sleep(3)  # Wait for the password field to appear

    # Locate the password field and enter the password
    password_field = driver.find_element(By.XPATH, "//input[@name = 'password']")
    password_field.send_keys(password)
    password_field.send_keys(Keys.RETURN)
    time.sleep(3)  # Wait for login to complete

    print("Logged in using Twitter authentication.")

def signin_google(gmail):
    # Navigate to Twitter login page
    time.sleep(3)  # Wait for the page to load

    # Locate and click the Google login button by its class name
    google_login_button = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.XPATH, "//span[text()='Sign in with Google']"))
    )
    google_login_button.click()



    print("Clicked on Login with Google button.")
    time.sleep(2)
    # Continue the Google login process (entering email, password, etc.)

def signin_apple(email_phone_no, password):
    # Navigate to Twitter login page
    time.sleep(3)  # Wait for the page to load

    # Locate and click the Apple login button by its class name
    apple_login_button = driver.find_element(By.XPATH, "//button[@class = 'css-175oi2r r-sdzlij r-1phboty r-rs99b7 r-lrvibr r-ywje51 r-184id4b r-eu3ka r-1ipicw7 r-2yi16 r-1qi8awa r-3pj75a r-1loqt21 r-o7ynqc r-6416eg r-1ny4l3l']")
    apple_login_button.click()

    print("Clicked on Login with Apple button.")
    time.sleep(2)
    # Continue the Apple login process (entering credentials, etc.)

# Ask for user credentials based on the chosen method
if login_method == "1":
    username = input("Enter your Twitter username or email: ")
    password = input("Enter your Twitter password: ")
    signin_twitter_auth(username, password)
elif login_method == "2":
    gmail = input("Enter your Google email: ")
    signin_google(gmail)
elif login_method == "3":
    apple_email_phone = input("Enter your Apple email or phone number: ")
    apple_password = input("Enter your Apple password: ")
    signin_apple(apple_email_phone, apple_password)
else:
    print("Invalid option selected.")



